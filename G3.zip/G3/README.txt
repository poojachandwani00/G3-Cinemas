Project Name : Movie Booking Website (IT Mini Project)
Project Done by : Arunachalam M

The SQL connections made in  the php files are of user : arun and password : mypasswd. Name of the database used is dreamworld. 19 sql tables have been used.


Login.php file and logout.php is kept outside instead of the homepage because the first page I have used is login and then after his credentials are verified, then the main page is loaded. So thats why I have kept login.php outside.
